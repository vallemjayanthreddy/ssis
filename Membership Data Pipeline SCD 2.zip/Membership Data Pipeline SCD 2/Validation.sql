use demo
/*Select all records from the membership table*/
select * from [dbo].[membership];
/*Truncating the membership table*/
truncate table [dbo].[membership];
/*Record count from the membership table*/
select count(*) from [dbo].[membership];
/*----------------------------------------------------------*/

/*Select all records from the staging table*/
select * from [dbo].[stag_membership];
/*Truncating the staging table*/
truncate table [dbo].[stag_membership];
/*Record count from the staging table*/
select * from [dbo].[stag_membership];
/*----------------------------------------------------------*/
/*Select all records from the control table*/
select * from [dbo].[control_table];
/*Truncating the control table*/
truncate table [dbo].[control_table];
/*Record count from the control table*/
select * from [dbo].[control_table];
/*----------------------------------------------------------*/

/*Validation for update rows and updatedate column*/
select * from [dbo].[membership]
where LastName ='Vallem';

/*----------------------------------------------------------*/

INSERT INTO [Demo].[dbo].[control_table] ([RowsProcessed], [NewRows], [UpdateRows], [LoadDate])
VALUES
    (400, 200, 120, '2024-10-07');
/*----------------------------------------------------------*/














