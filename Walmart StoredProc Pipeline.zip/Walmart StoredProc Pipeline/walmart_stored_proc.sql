USE [walmart]
GO

/****** Object:  StoredProcedure [dbo].[BatchLoadWalmart]    Script Date: 11-10-2024 14:44:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[BatchLoadWalmart]
@FileName NVARCHAR(255)
AS
BEGIN

--## Declaring and Initializing variables. ##--
	DECLARE @BatchStart DATETIME;
	DECLARE @BatchEnd DATETIME;
	DECLARE @BatchSize INT =30;
	DECLARE @BatchID INT =1;
	DECLARE @RemainingRows INT;
	DECLARE @TotalRows INT;
	DECLARE @BatchRows INT;

	SELECT @TotalRows = COUNT(*) FROM stag_store_data;
	SET @RemainingRows = @TotalRows;

	-- Create a temporary table to store batch results(Cannot insert into two tables with one CTE)
    CREATE TABLE #BatchResults (
        Store INT,
        SaleDate DATE,
        Weekly_Sales FLOAT,
        Holiday_Flag BIT,
        Temperature FLOAT,
        Fuel_Price FLOAT,
        CPI FLOAT,
        Unemployment FLOAT
    );

	WHILE (@RemainingRows > 0)
	BEGIN
	---Truncate temptable before loading batch rows
	TRUNCATE TABLE #BatchResults;

	--Initialize @BatchStart 
	SET @BatchStart = GETDATE();

	---Extracting the batch rows 

	 WITH Batch AS (
        SELECT TOP(@BatchSize)
		[Store],[SaleDate], [Weekly_Sales], [Holiday_Flag], [Temperature], [Fuel_Price], [CPI], [Unemployment]
        FROM stag_store_data
        WHERE Processed_Flag = 0
        ORDER BY SaleDate DESC
    )


	--Storing the batch rows in a Temp table
	INSERT INTO #BatchResults
        SELECT *
        FROM Batch;


	---Inserting into sales_fact Table
	INSERT INTO sales_fact (Store, SaleDate, Weekly_Sales, Holiday_Flag)
    SELECT Store, SaleDate, Weekly_Sales, Holiday_Flag 
    FROM #BatchResults;


	---Inserting into store_metrics Table
	INSERT INTO store_metrics (Store, SaleDate, Temperature, Fuel_Price, CPI, Unemployment)
    SELECT Store, SaleDate, Temperature, Fuel_Price, CPI, Unemployment 
    FROM #BatchResults;


	---Initializing @BatchRows
	SELECT @BatchRows = COUNT(*) FROM #BatchResults ;


	---Update @RemainingRows based on @BatchRows
	SET @RemainingRows = @RemainingRows - @BatchRows;


	---Updating Processed_Flag to 1
	UPDATE stag_store_data
	SET Processed_Flag = 1
	where SaleDate IN (SELECT SaleDate FROM #BatchResults );


	--Initialize @BatchStart 
	SET @BatchEnd = GETDATE();

	--Inserting into control table
	INSERT INTO control_table([BatchID], [FileName], [BatchRows], [TotalRows], [BatchStart], [BatchEnd])
	VALUES(@BatchID, @FileName, @BatchRows, @TotalRows, @BatchStart, @BatchEnd)


	--Set BatchID
	SET @BatchID = @BatchID+1;

	
	END
	DROP TABLE #BatchResults;
END;
GO


